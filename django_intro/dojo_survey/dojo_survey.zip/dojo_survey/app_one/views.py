from django.shortcuts import render, redirect

def index(request):
    return render(request, "index.html")

def result(request):
    name_from_form = request.POST['name']
    location_from_form = request.POST['Dojolocation']
    language_from_form = request.POST['FavoriteLanguage']
    comment_from_form = request.POST['description']
    info = {
        "name_on_template": name_from_form,
        "location_on_template": location_from_form,
        "language_on_template": language_from_form,
        "comment_on_template": comment_from_form,
    }
    return render(request, "results.html", info)

