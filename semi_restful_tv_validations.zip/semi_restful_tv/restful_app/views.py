from django.shortcuts import render, redirect
from .models import Shows
from django.contrib import messages

# Create your views here.
def index(request):
    context = {
        "all_shows": Shows.objects.all()
    }
    return render(request, 'all_shows.html', context)

# **************************
# displays all shows
# **************************

def display_shows(request, id):
    context = {
        "show": Shows.objects.get(id=id)
    }
    return render(request, 'display_shows.html', context)

def edit_shows(request, id):
    context  = {
        "show": Shows.objects.get(id=id)
    }
    return render(request, 'edit_shows.html', context)

# *************************
# add a new show
# *************************

def add_shows(request):
    return render(request, 'add_shows.html')


def create_shows(request):
    print(request.POST)
    errors = Shows.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/shows/new")
    else:
        new_show = Shows.objects.create(title=request.POST['title'], network=request.POST['network'], release_date=request.POST['release_date'], description=request.POST['description'])
        new_show_id = new_show.id
        return redirect(f'shows/{new_show_id}')

def updated_shows(request, id):
    print(request.POST)
    errors = Shows.objects.basic_validator(request.POST)
    
    if errors:
        for key in errors:
            messages.error(request, errors[key])

    if errors:
        return redirect(f'/shows/{show.id}/edit')

    edited_show = Shows.objects.get(id=id)
    edited_show.network = request.POST['network']
    edited_show.release_date = request.POST['release_date']
    edited_show.description = request.POST['description']
    edited_show.save()
    return redirect(f'/shows/{id}')

def delete_shows(request, id):
    Shows.objects.get(id=id).delete()
    return redirect("/shows")




