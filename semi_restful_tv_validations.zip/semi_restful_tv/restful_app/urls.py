from django.urls import path

from . import views

urlpatterns = [
    path('shows', views.index),
    path('shows/<int:id>', views.display_shows),
    path('shows/<int:id>/edit', views.edit_shows),
    path('shows/new', views.add_shows),
    path('create_shows', views.create_shows),
    path('edit_shows/<int:id>', views.updated_shows),
    path('delete_shows/<int:id>', views.delete_shows)
]